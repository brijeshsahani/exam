<?php
    include 'connection.php';

    extract($_GET);

    $query = "DELETE from user where id='$id'";

    $result = mysqli_query($conn,$query);

    if($result==true)
    {
        header('location:display.php');
    }
    else
    {
        echo "Not Deleted";
    }

?>
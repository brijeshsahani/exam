<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form method="get">
        <table align="center" border="2">
            <tr>
                <td>ID</td>
                <td>USERNAME</td>
                <td>PASSWORD</td>
                <td>Image</td>
                <td>EDIT</td>
                <td>DELETE</td>
            </tr>
     

        <?php
            include 'connection.php';

            $query = "SELECT *from user";

            $result = mysqli_query($conn,$query);

            while($res = mysqli_fetch_array($result)){
                ?>
            <tr>
                <td><?php echo $res['id'] ?></td>
                <td><?php echo $res['username'] ?></td>
                <td><?php echo $res['password'] ?></td>
                <td><?php echo "<img src='images/".$res['image']."'.height='100' width='100' >"; ?></td>
                <td><a href="update.php?id=<?php echo $res['id']?>">Edit</a></td>
                <td><a href="delete.php?id=<?php echo $res['id']?>">Delete</a></td>
            </tr>

           <?php }
        ?>
            <tr><td><a href="create.php">Insert</a></td></tr>
           </table> 
    </form>
    
</body>
</html>
<?php

    $conn = mysqli_connect('localhost','root','root','extphp');

    if(!$conn)
    {
        echo "Not Connected";
    }
?>
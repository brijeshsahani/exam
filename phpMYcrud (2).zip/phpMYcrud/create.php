<?php

    include 'connection.php';

    if(count($_POST)!=0)
    {
        extract($_POST);
        $image = $_FILES['image']['name'];
        $tmp = $_FILES['image']['tmp_name'];
        move_uploaded_file($tmp,'images/'.$image);
 
        $query = "INSERT INTO user (username,password,image) values ('$username','$password','$image')";

        $result = mysqli_query($conn,$query);

        if($result==true)
        {
            echo "Inserted";   
        }
        else
        {
            echo "Not Inserted";   
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

        <form method="post" enctype="multipart/form-data">
            <h1 align="center">Insert Data</h1>
           <table align="center" border="2">
                <tr>
                    <td><label for="username">Username : </label></td>
                    <td><input type="text" name="username"></td>
                </tr>

                <tr>
                    <td><label for="password">Password : </label></td>
                    <td><input type="text" name="password"></td>
                </tr>

                <tr>
                    <td><label for="file">select : </label></td>
                    <td><input type="file" name="image"></td>
                </tr>

                <tr>
                    <td></td>
                    <td><input type="submit" name="insert"></td>
                </tr>

                <tr>
                    <td></td>
                    <td><a href="display.php">Records</a></td>
                </tr>
           </table>

        </form>
    
</body>
</html>